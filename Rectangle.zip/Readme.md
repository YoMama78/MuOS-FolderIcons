# MuOS FolderIcon rectangled with rounded corners and logo

Logos taken from:
https://forums.launchbox-app.com/files/file/3402-v2-platform-logos-professionally-redrawn-official-versions-new-bigbox-defaults/

Dear Dan Patrick, thank you so much for your amazing work! 
https://forums.launchbox-app.com/profile/85709-dan-patrick/

Size 250x150px -> Perfect for bottom right positioning in the list view ;-)

==EXAMPLES==

![NEOGEO Logo](https://github.com/YoMama78/MuOS-FolderIcons/blob/main/Rectangle/NEOGEO.png?raw=true)

![SEGA Saturn Logo](https://github.com/YoMama78/MuOS-FolderIcons/blob/main/Rectangle/SATURN.png?raw=true)

![MAME Logo](https://github.com/YoMama78/MuOS-FolderIcons/blob/main/Rectangle/MAME.png?raw=true)
