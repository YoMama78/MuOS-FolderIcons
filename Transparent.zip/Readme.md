# MuOS FolderIcon with transparent fading background and Logo

Logos taken from:
https://forums.launchbox-app.com/files/file/3402-v2-platform-logos-professionally-redrawn-official-versions-new-bigbox-defaults/

Dear Dan Patrick, thank you so much for your amazing work! 
https://forums.launchbox-app.com/profile/85709-dan-patrick/

==EXAMPLES==

![NEOGEO Logo](https://github.com/YoMama78/MuOS-FolderIcons/blob/main/Transparent/NEOGEO.png?raw=true)

![SEGA Saturn Logo](https://github.com/YoMama78/MuOS-FolderIcons/blob/main/Transparent/SATURN.png?raw=true)

![MAME Logo](https://github.com/YoMama78/MuOS-FolderIcons/blob/main/Transparent/MAME.png?raw=true)
